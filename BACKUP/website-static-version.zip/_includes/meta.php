<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="googlebot" content="index, follow">
<meta name="robots" content="index, follow">
<meta name="keywords" content="free, templates, themes, download, freethemes, freetemplates, download templates, download themes">
<meta name="description" content="Free HTML Web Templates. The place where you can download web templates just for free.">
<meta name="author" content="Lubomir Georgiev - Любомир Георгиев">
<meta name="google-site-verification" content="3nWtTeNPrK0SctjkkqHfrYqDf35racWRXe99NQyAcPg" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="http://freetemplatesdownload.info/favicon.png" type="image/x-icon">