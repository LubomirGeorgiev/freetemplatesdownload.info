<li class="link1"><a href="http://freetemplatesdownload.info/">Home</a></li>
<li class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown">Templates <b class="caret"></b></a>
  <ul class="dropdown-menu">
    <li class="link2"><a href="http://freetemplatesdownload.info/template/businessbox.html?utm_source=MainNav&utm_medium=referral&utm_campaign=MainNav+to+Template">BusinessBox</a></li>
    <li class="link6"><a href="http://freetemplatesdownload.info/template/urbanprism.html?utm_source=MainNav&utm_medium=referral&utm_campaign=MainNav+to+Template">Urban Prism</a></li>
    <li class="link3"><a href="http://freetemplatesdownload.info/template/freshco.html?utm_source=MainNav&utm_medium=referral&utm_campaign=MainNav+to+Template">FreshCO</a></li>
    <li class="link4"><a href="http://freetemplatesdownload.info/template/yourcoolportfolio.html?utm_source=MainNav&utm_medium=referral&utm_campaign=MainNav+to+Template">Your Cool Portfolio</a></li>
    <li class="link5"><a href="http://freetemplatesdownload.info/template/yourflatportfolio.html?utm_source=MainNav&utm_medium=referral&utm_campaign=MainNav+to+Template">Your Flat Portfolio</a></li>
	<li class="puritylink"><a href="http://freetemplatesdownload.info/template/purity.html?utm_source=MainNav&utm_medium=referral&utm_campaign=MainNav+to+Template">Purity</a></li>
	<li class="pagerlink"><a href="http://freetemplatesdownload.info/template/pager.html?utm_source=MainNav&utm_medium=referral&utm_campaign=MainNav+to+Template">Pager</a></li>
  </ul>
</li>
<li class="all-templateslink"><a href="http://freetemplatesdownload.info/all-templates.html">All templates</a></li>
<li><a href="https://github.com/LubomirGeorgiev/freetemplatesdownload.info" target="_blank">GitHub Project</a></li>
<li><a href="https://github.com/LubomirGeorgiev/freetemplatesdownload.info/issues/new" target="_blank">Report a bug</a></li>
<div class="navbar-form navbar-right buttons">
  <!--<a href="https://twitter.com/share" class="twitter-share-button" data-url="http://freetemplatesdownload.info" data-text="Free website templates, tutorials and more at" data-hashtags="freetemplatesdownload">Tweet</a>
  <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>-->
	<a class="btn btn-success blog-button" href="http://freetemplatesdownload.info/blog/?utm_source=MainNav&utm_medium=referral&utm_campaign=MainNavGreenButton+to+Blog">BLOG</a>
	<a class="btn btn-default" href="http://freetemplatesdownload.info/sitemap.html?utm_source=MainNav&utm_medium=referral&utm_campaign=MainNavButton+to+sitemap">Sitemap</a>
</div>