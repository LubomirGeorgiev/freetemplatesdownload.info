<div class="menu-wrap">
      <nav role="navigation" class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
              <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a href="http://freetemplatesdownload.info/">
              	<div class="logo-holder">
              		<img class="img-responsive" src="http://freetemplatesdownload.info/images/logo.min.svg">
              	</div>
              </a>
            </div>

            <div class="collapse navbar-collapse navbar-collapse">
              <ul class="nav navbar-nav">
                <?php include 'nav-links-content.php'; ?>
              </ul>
            </div>
          </div>
      </nav>
</div>