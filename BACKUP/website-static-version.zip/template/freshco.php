<!DOCTYPE html>
<html lang="en">
  <head>
    <title>FreshCO - A Free Web Template | FreeTemplatesDownload.info</title>
    <?php include '../_includes/meta.php'; ?>
	<link href="../css/global.css<?php include '../_includes/stylesheet_version.php'; ?>" rel="stylesheet" media="screen">
  
<?php include '../_includes/google-analytics.php'; ?>
  </head>
<body class="page template-review-single">

<!-- NAV BAR -->
<?php include '../_includes/main-nav.php'; ?>
<!-- NAV BAR -->

<div class="container">
<div class="template-details clearfix">
    <a href="http://freetemplatesdownload.info/livepreview/freshco/">
    <h1>FreshCO</h1>
    <h4>A free, fresh looking web templatertists as a portfolio page.</h4>
    <div class="promobillboard">
    <img alt="FreshCo is a free web template. - Fresh looking, Fully responsible, Beautiful, Full Screen Slider, Multipurpose use, Mobile friendly, Beautiful design" class="img-responsive" src="http://freetemplatesdownload.info/images/promobillboards/freshco.jpg">
    </div></a>

<div class="promobuttons">
    <a class="btn btn-danger button" href="http://freetemplatesdownload.info/download/freshco.zip">Download</a>
    <a class="btn btn-success button" href="http://freetemplatesdownload.info/livepreview/freshco/">Live preview</a>
</div>
</div>
</div><!-- /.container -->

<?php include '../_includes/footer.php'; ?>

<script src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html>