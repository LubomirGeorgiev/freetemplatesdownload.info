<?php
   header( 'Location: http://www.freetemplatesdownload.info/all-templates.html' ) ;
?>